<h1 align="center"><b> THE X-Troid Public Bot  </b></h1>

![logo](https://telegra.ph/file/569fd05fb4c587a360d38.jpg)




<p align="center">
    Project of X-Troid - Makes it easy and fun to use Whatsapp. Also first Sinhala userbot for Whatsapp.
    <br>
        <a href="http://t.me/danumabots">Telegram Channel</a> |
        <a href="https://t.me/danuma01">Telegram Group</a> |
        <a href="https://chat.whatsapp.com/JigWG8oj1hj1YXLgJaqxta">New Support Group</a> |
        <a href="https://t.me/unofficialplugin">All Groups & channels </a> |
    <br>
</p>

[![Run on Repl.it](https://repl.it/badge/github/phaticusthiccy/WhatsAsenaDuplicated)](https://replit.com/@lasindu123/XTROID)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/lasiyaWA/X-Troid)

### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```
### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark

## Thanks To
[![Yusuf Usta](https://github.com/yusufusta.png?size=50)](https://t.me/fusufs)  | [![CW4RR10R](https://github.com/CW4RR10R.png?size=50)](https://github.com/CW4RR10R)
----|----|
[Yusuf Usta](https://t.me/fusufs) | [CW4RR10R](https://t.meW4RR10R)
 Base, | hepls,idea

# base bot
https://github.com/yusufusta/WhatsAsena

# Baileys whatsapp api 
https://github.com/adiwajshing/Baileys
